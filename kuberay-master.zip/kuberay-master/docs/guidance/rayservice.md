This document has been moved to the [Ray documentation](https://docs.ray.io/en/master/cluster/kubernetes/getting-started/rayservice-quick-start.html).
