This document has been moved to the [Ray documentation](https://docs.ray.io/en/master/cluster/kubernetes/user-guides/rayserve-dev-doc.html#kuberay-dev-serve).
