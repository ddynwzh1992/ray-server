This document has been moved to the [Ray documentation](https://docs.ray.io/en/latest/cluster/kubernetes/index.html).
